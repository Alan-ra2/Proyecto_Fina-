<?php
define("urlsite","http://localhost/almacen/");
?>