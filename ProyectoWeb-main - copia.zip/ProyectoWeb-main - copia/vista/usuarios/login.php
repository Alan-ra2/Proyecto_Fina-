<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="vista/css/style.css">

</head>

<!--EJEMPLO PARA MEJORAR EL LOGIN-->
<!--<div class="login">
        <div class="form-container">
            <img src="" alt="logo"
            class="logo">
            <h1 class="title">Create a new-password</h1>
            <p class="subtitle">Enter a new password for your account</p>

            <form action="/" class="form">
                <label for="passwr" class="label">Password</label>
                <input type="password" id="password" placeholder="*********" class="input input-password">

                <label for="new-password" class="label">Password</label>
                <input type="password" id="new-password" placeholder="*********" class="input input-password">
                <input type="submit" value="confirm" class="primary-buttom login-button">

            </form>-->
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h2 class="text-center mt-5">Login: </h2>
                <form action="process_login.php" method="POST">
                    <div class="form-group">
                        <label for="email">Correo Electrónico:</label>
                        <input type="email" class="form-control" id="email"placeholder="ejemplocorreo@gmail.com" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Contraseña:</label>
                        <input type="password" class="form-control" id="password" placeholder="*********" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Iniciar Sesión</button>
                </form>
                <a href="index.php" class="btn btn-secondary btn-block mt-3">Regresar al Inicio</a>
                <a href="index.php?u=registro" class="btn btn-info btn-block mt-3">Registrarse</a>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>