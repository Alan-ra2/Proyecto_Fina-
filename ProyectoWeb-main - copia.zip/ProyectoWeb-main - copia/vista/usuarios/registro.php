<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="vista/css/style.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Formulario de Registro</h2>
        <form action="procesar_registro.php" method="post">
            <div class="form-group">
                <label for="nombre">Nombre:</label>
                <input type="text" class="form-control" id="nombre" name="nombre" required>
            </div>
            <div class="form-group">
                <label for="apellidos">Apellidos:</label>
                <input type="text" class="form-control" id="apellidos"  name="apellidos" required>
            </div>
            <div class="form-group">
                <label for="correo">Correo Electrónico:</label>
                <input type="email" class="form-control" id="correo" placeholder="ejemplocorreo@gmail.com"name="correo" required>
            </div>
            <div class="form-group">
                <label for="contrasena">Contraseña:</label>
                <input type="password" class="form-control" id="contrasena" placeholder="*********"name="contrasena" required>
            </div>
            <div class="form-group">
                <label for="telefono">Teléfono:</label>
                <input type="tel" class="form-control" id="telefono"placeholder="NUM. ejemplo: 9617789594" name="telefono" required>
            </div>
            <!--
            <div class="form-group">
                <label for="curp">CURP:</label>
                <input type="text" class="form-control" id="curp" name="curp" required>
            </div>-->
            <button type="submit" class="btn btn-primary">Registrarse</button>
            <a href="index.php" class="btn btn-secondary">Regresar al Inicio</a>
            <a href="index.php?u=login" class="btn btn-info">Ir al Login</a>
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
