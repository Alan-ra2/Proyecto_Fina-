<?php
class IndexModel{
    private $db;
}
?>